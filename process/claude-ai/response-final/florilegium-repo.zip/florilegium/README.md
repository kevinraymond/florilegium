# florilegium

Procedurally generated floral page margins, drawn entirely in TikZ. No images, no
imported paths, no external assets: every petal is a parametric curve evaluated while the
page is being written, and every page gets its own garden.

![six seeds](gallery/seeds.gif)

*Six seeds of the grown composition. Same code, different seed — and the garden fills
whatever space the text leaves free.*

Two documents share one package:

| | `florilegium.tex` | `florilegium-grow.tex` |
|---|---|---|
| composition | **authored**: anchors placed by hand, every parameter sampled | **grown**: layout computed in Lua by a greedy space-filling loop |
| engine | `pdflatex` (or any) | `lualatex`, two passes |
| adapts to | nothing (tuned for A4, 68 mm margin) | the page layout, and the free space below the text on the last page |
| preview | ![authored](gallery/preview-authored.png) | ![grown](gallery/preview-grown.png) |

Both PDFs are self-describing: the body text is the write-up of how the margin is drawn.

![last page of the grown document](gallery/preview-grown-lastpage.png)

*Last page of the grown document: the text ends early, so the garden takes the rest.*

![petal detail](gallery/detail.png)

*300 dpi crop. Ruffled petals with brushed streaks, dissected leaves, florets, an umbel.*

## Build

```sh
make                        # both PDFs
make seed-7                 # one page from seed 7 -> build/seed-7.pdf
make gallery SEEDS="1 2 3"  # gallery/seeds.png + seeds.gif (python3, Pillow, pdftoppm)
```

Or paste `florilegium.sty`, `grow.lua` and one of the `.tex` files into an
[Overleaf](https://www.overleaf.com) project (set the compiler to LuaLaTeX for the grown
one). Expect ~35 s per page for the authored document and ~60 s per page for the grown one;
the cost is `pgfmath`, not the layout.

Use it in your own document:

```latex
\usepackage[grown]{florilegium}      % or plain \usepackage{florilegium}
\definecolor{ink}{HTML}{5B2A1F}      % optional: change the hue
...
\florilegiumtextend                  % grown only: at the very end of the text
```

A fixed seed instead of the page number: `lualatex "\def\florilegiumseed{7}\input{florilegium-grow.tex}"`.

## How it works

**Primitives** (`florilegium.sty`). A petal is an egg curve times a *ruffle*, a sum of three
sines at incommensurate frequencies with phases drawn once per petal; the outline is
deterministic after that, so it is computed once and reused as fill, clip and stroke
(`save path` / `use path`). Inside the clip: nine dark and six pale lens-shaped streaks
(the whole "brushed" texture), seven hairline veins, and the outline restroked wide so only
its inner half shows. Leaves are two parametric plots joined at a pointed tip, with width,
serration depth, tooth count and curl as parameters — one macro gives serrated leaflets and
grass blades; a dissected leaf is a rib carrying leaflets. Sprays are a recursive ternary
branching ending in five-petal florets; arch sprays hang sprays along a bent stalk with
`decorations.markings`; umbels fan rays into secondary umbels; tendrils are logarithmic
spirals. One hue in tints, one gold accent.

**Authored composition.** Two smooth-plot stalks through jittered control points; leaves
hung along them by path markings so they follow the tangent; named anchors at fractions
of the arc; everything else attached to short side branches from those anchors, drawn in
depth order.

**Grown composition** (`grow.lua`), in the spirit of Wong, Zongker & Salesin,
[*Computer-Generated Floral Ornament*](https://dl.acm.org/doi/10.1145/280814.280948)
(SIGGRAPH 1998). Every motif has a proxy disc. The free region is seeded with a vine;
then, repeatedly: take the grid point with the largest free radius that is within reach of
something already drawn, pick a motif that fits it (by weight, with per-kind caps that
scale with the region's area), size it to the hole, orient it away from its nearest
anchor, connect it with a stem, and add its proxy. Stop when only ornament-sized holes
remain. Big holes are taken first, so flowers and dissected leaves land early, sprays and
ferns fill the middle, and buds, tendrils and small ornaments close the gaps — that
ordering is what makes the result look composed. The region is read from the page layout,
and the end of the text is recorded with `zref-savepos`, so a short last page gets a
garden across the empty space.

**Procedural ≠ random.** The seed is derived from the page number, so page *n* always
gets garden *n*. Reproducibility is what makes the document stable enough to typeset.

## Things worth knowing

- pgfmath computes in TeX dimensions: integers and intermediates must stay below 16 384.
- A coordinate component containing parentheses must be braced: `({sin(\a)},{cos(\a)})`.
- `\fi` is not a loop variable. Neither is `\a`, `\d` or `\L`.
- `line width` does not scale with `scale=`, which keeps stroke weight consistent.
- Gradients are drawn in the path's local frame, so they rotate with the petal.
- When the generator outgrows TeX macros, do the thinking in Lua and the drawing in TikZ.
  That split is the whole architecture here.

See [CLAUDE.md](CLAUDE.md) for a handoff-style map of the code, the tunables, and ideas not
yet done.

## Origin

A Reddit thread asked how a classmate's lecture notes got procedurally generated TikZ
flowers in the margin, with the source kept closed. This repo is an open answer: it
doesn't reproduce that document, it shows that the technique is authored primitives plus
procedural placement, and that the "adapts to the unused space" part is a 1998 idea from the
ornament literature.

## License

MIT.
