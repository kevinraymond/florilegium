# florilegium — handoff notes

Procedurally generated "Delft blue" floral page margins, drawn entirely in TikZ.
Two documents share one package: an **authored** composition (hand-placed anchors,
parameters sampled) and a **grown** one (layout computed in Lua by a greedy
space-filling loop, drawing by the same primitives). No images, no assets.

## Files

| file | what |
|---|---|
| `florilegium.sty` | the package: palette, all primitives, the authored composition, the plumbing. Options `authored` (default) and `grown` (LuaLaTeX only). |
| `grow.lua` | the growth stage for `[grown]`: region, vine, candidate grid, motif table, placement loop; emits TikZ via `tex.print`. |
| `florilegium.tex` | demo document, authored composition, `pdflatex`. Body text = `text-methods.tex` + `text-sharing.tex`. |
| `florilegium-grow.tex` | demo document, grown composition, `lualatex` ×2. Body text adds `text-growth.tex`; ends with `\florilegiumtextend` so the garden spills below the text on the last page. |
| `gallery.tex` | one short page, used per seed by `tools/gallery.py` and `make seed-N`. |
| `tools/gallery.py` | builds N seeds, writes `gallery/seeds.png` (contact sheet) and `gallery/seeds.gif`. |
| `florilegium-v1.tex` | the first, self-contained version (plain Bézier petals, ~10 s/page). Kept as the lightest starting point. |

## Build

```sh
make                 # both PDFs
make florilegium.pdf # pdflatex, ~35 s/page
make florilegium-grow.pdf   # lualatex twice (zref needs the .aux), ~60 s/page + spill
make seed-7          # one page for seed 7 -> build/seed-7.pdf
make gallery SEEDS="1 2 3"  # contact sheet + gif (python3, Pillow, pdftoppm)
```

Fixed seed from the command line: `lualatex "\def\florilegiumseed{7}\input{florilegium-grow.tex}"`.
Seeds are small integers (1–150) because pgfmath integers must stay below 16 384.

Look at output with `pdftoppm -png -r 100 file.pdf page` and read the PNG; for fine
detail use `-r 300` with `-x -y -W -H` crops. Always look before declaring a change good.

## Conventions and traps (each of these cost real time)

- **Brace coordinate components that contain parentheses**: `({sin(\a)},{cos(\a)})`.
  TikZ reads a coordinate up to the first `)`. Symptom: "No shape named `0' is known".
- **`\foreach` variables must not be existing control sequences.** `\fi`, `\a`, `\d`, `\L`
  are all taken. Symptom: "Extra }, or forgotten \endgroup" at shipout.
- **pgfmath is TeX-dimension arithmetic**: every integer and intermediate < 16 384.
  Convert sp to cm with `\the\dimexpr ... sp\relax/1cm`, never by dividing in pgfmath.
- A primitive outline that is needed for fill, clip and stroke is computed once with
  `save path=\p` and reused with `use path=\p`. Keep that pattern; it is a 3× saving.
- Deterministic noise (sum of sines with per-instance phases) instead of `rand` inside
  a `plot`, whenever the same curve has to be reproduced.
- `\usepgflibrary{luamath}` with `/pgf/luamath/parser` **breaks** under the markings
  decorations ("Extra }"). Don't retry it without isolating that first.
- This container's TeX Live lacks `lmodern`/`babel-french` and luaotfload's font
  database; the documents pin Computer Modern under LuaLaTeX for that reason. On a
  full install it is harmless to remove those lines.
- The authored composition's coordinates are tuned for A4 with a 68 mm left margin.
  The grown one reads the layout (`\oddsidemargin`, `\textwidth`, `\textheight` …) and
  adapts.

## How the growth works (grow.lua)

1. Region = margin column, plus the rectangle under the text on the last page when
   `\florilegiumtextend` recorded a position (zref-savepos, hence two passes).
2. Vine and a phase-shifted companion stalk through the column (Catmull-Rom through
   zig-zag control points); one wavy branch per ~7 cm of spill height. Their samples
   are the initial anchors.
3. Candidate grid (2 mm). Each cell keeps `free` (largest disc radius that fits,
   with existing proxies counted at `OVERLAP` of their radius) and `adist` (distance
   to the nearest anchor). Both are updated incrementally on placement.
4. Loop: pick the cell with the largest `free · U(0.85,1.15)` within `REACH` of an
   anchor; choose a motif by weight among those whose smallest proxy fits and whose
   cap (`max · area/165`) isn't reached; scale it so `r(s) ≈ 0.92·free`; orient away
   from the nearest anchor; emit a stem and the primitive call; add its proxy and
   anchors. Stop below `SMALLEST`.
5. Output is buffered per layer (0 stalks, 1 stems, 3 airy, 4 foliage, 5 bells/buds,
   6 flowers, 7 ornaments) and printed in that order inside a clip of the region.

To add a motif: write the primitive in the `.sty` (origin at its base or centre, points
along +x or +y, uses `rand`/`rnd`), then add a table row in `grow.lua` with `r(s)`
(proxy radius), `off(s)` (distance from disc centre back to the origin), `rot(ang)`,
layer, weight, cap and `code(s, ang)`.

## Ideas not done

- Replace the proxy *disc* with 2–3 discs for long motifs (blades, arch sprays).
- Let the text's own shape matter: read `\pagetotal`-style free space on every page,
  not just the last; or declare extra free rectangles around floats.
- Perlin-style noise field for the vine instead of zig-zag control points.
- A second hue (`ink2`) for depth; a "sepia" palette.
- Speed: the primitives are the cost (pgfmath). A LuaTeX path-emitting version of
  `\petal`/`\leafshape` (compute the samples in Lua, print the `plot coordinates`)
  would cut compile time several-fold.
