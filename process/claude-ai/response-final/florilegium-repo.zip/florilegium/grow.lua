-- grow.lua -- adaptive layout for florilegium.sty (LuaLaTeX only)
--
-- A greedy space-filling placement in the spirit of Wong, Zongker & Salesin,
-- "Computer-Generated Floral Ornament" (SIGGRAPH 1998):
--   1. seed the region with a vine (and a branch into any extra free region);
--   2. repeatedly find the largest free disc that is within reach of something
--      already drawn, choose a motif that fits it, place the motif facing away
--      from its anchor and connect it with a stem;
--   3. stop when no free disc larger than the smallest motif remains.
-- Big motifs are picked first because the biggest holes are found first, and
-- the loop ends by tucking ornaments into the leftover gaps.
--
-- The module only decides *where* and *how big*; the drawing is done by the
-- TikZ primitives of florilegium.sty, whose own parameters are still randomised
-- by pgfmath. Everything here is deterministic for a given seed.

local M = {}

local fmt, sqrt, cos, sin, atan, pi = string.format, math.sqrt, math.cos, math.sin, math.atan, math.pi
local function num(v) return fmt("%.3f", v) end
local function dist(ax, ay, bx, by) local dx, dy = ax - bx, ay - by return sqrt(dx * dx + dy * dy) end
local function rnd(a, b) return a + (b - a) * math.random() end
local function deg(a) return a * 180 / pi end

-- ---------------------------------------------------------------- curves
-- Catmull-Rom samples through control points {{x,y},...}, `per` samples per segment
local function catmull(pts, per)
  local out, n = {}, #pts
  for i = 1, n - 1 do
    local p0, p1, p2, p3 = pts[math.max(i - 1, 1)], pts[i], pts[i + 1], pts[math.min(i + 2, n)]
    for k = 0, per - 1 do
      local t = k / per; local t2, t3 = t * t, t * t * t
      local x = 0.5 * (2 * p1[1] + (-p0[1] + p2[1]) * t + (2 * p0[1] - 5 * p1[1] + 4 * p2[1] - p3[1]) * t2 + (-p0[1] + 3 * p1[1] - 3 * p2[1] + p3[1]) * t3)
      local y = 0.5 * (2 * p1[2] + (-p0[2] + p2[2]) * t + (2 * p0[2] - 5 * p1[2] + 4 * p2[2] - p3[2]) * t2 + (-p0[2] + 3 * p1[2] - 3 * p2[2] + p3[2]) * t3)
      out[#out + 1] = { x, y }
    end
  end
  out[#out + 1] = { pts[n][1], pts[n][2] }
  return out
end

local function coords(samples)
  local t = {}
  for i, p in ipairs(samples) do t[i] = "(" .. num(p[1]) .. "," .. num(p[2]) .. ")" end
  return table.concat(t, " ")
end

-- ---------------------------------------------------------------- motifs
-- r(s): proxy disc radius at scale s; off(s): distance from the disc centre back
-- toward the anchor at which the primitive's origin sits; rot(ang): rotation of the
-- local frame given the direction angle (degrees) from anchor to centre.
local motifs = {
  { name = "flower",    w = 4,   smin = 0.8,  smax = 1.3, max = 3, layer = 6, stem = 0.8,
    r = function(s) return 1.05 * s end, off = function(s) return 0 end,
    code = function(s) return fmt("\\flower{%s}", num(s)) end },
  { name = "dissected", w = 3,   smin = 1.0,  smax = 1.5, max = 5, layer = 4, stem = 0.6,
    r = function(s) return 0.5 * s end, off = function(s) return 0.5 * s end, rot = function(a) return a end,
    code = function(s) return fmt("\\dissected{%s}", num(s)) end },
  { name = "umbel",     w = 2,   smin = 0.9,  smax = 1.7, max = 4, layer = 3, stem = 0.5,
    r = function(s) return 0.9 * s end, off = function(s) return 0.55 * s end, rot = function(a) return a - 90 end,
    code = function(s) return fmt("\\umbel{%s}", num(s)) end },
  { name = "archspray", w = 2,   smin = 1.6,  smax = 3.0, max = 4, layer = 3, stem = 0.5,
    r = function(s) return 0.52 * s end, off = function(s) return 0.5 * s end, rot = function(a) return a - 25 end,
    code = function(s) return fmt("\\archspray{%s}", num(s)) end },
  { name = "fern",      w = 1.5, smin = 1.4,  smax = 2.4, max = 3, layer = 3, stem = 0.5,
    r = function(s) return 0.5 * s end, off = function(s) return 0.5 * s end, rot = function(a) return a - 20 end,
    code = function(s) return fmt("\\fern{%s}", num(s)) end },
  { name = "spray",     w = 2,   smin = 0.45, smax = 0.6, max = 6, layer = 3, stem = 0.4,
    r = function(s) return 1.1 * s end, off = function(s) return 1.0 * s end, rot = function(a) return 0 end,
    code = function(s, ang) return fmt("\\spray{%s}{%s}{3}", num(ang), num(s)) end },
  { name = "bells",     w = 1.2, smin = 0.7,  smax = 1.0, max = 4, layer = 5, stem = 0.5, hang = true,
    r = function(s) return 0.6 * s end, off = function(s) return 0.5 * s end, rot = function(a) return 0 end,
    code = function(s) return fmt("\\bell{%s}\\begin{scope}[shift={(%s,%s)}]\\bell{%s}\\end{scope}", num(s), num(0.5 * s), num(0.25 * s), num(0.78 * s)) end },
  { name = "bud",       w = 1,   smin = 0.6,  smax = 0.9, max = 5, layer = 5, stem = 0.45,
    r = function(s) return 0.5 * s end, off = function(s) return 0.45 * s end, rot = function(a) return a - 90 end,
    code = function(s) return fmt("\\bud{%s}", num(s)) end },
  { name = "blade",     w = 1.5, smin = 1.3,  smax = 2.0, max = 6, layer = 4, stem = 0.4,
    r = function(s) return 0.28 * s end, off = function(s) return 0.5 * s end, rot = function(a) return a end,
    code = function(s) return fmt("\\blade{%s}{%s}", num(s), num(rnd(-0.35, 0.35))) end },
  { name = "tendril",   w = 1,   smin = 0.35, smax = 0.6, max = 5, layer = 3, stem = 0.35, spiral = true,
    r = function(s) return 1.0 * s end, off = function(s) return 0 end,
    code = function(s) return fmt("\\tendril{%s}", num(s)) end },
  { name = "pendant",   w = 0.7, smin = 0.3,  smax = 0.3, max = 6, layer = 7, hangs_len = 1.0,
    r = function(s) return 0.3 end, off = function(s) return 0 end,
    code = function(s) return "\\pendant{1.0}" end },
  { name = "ornament",  w = 3,   smin = 0.15, smax = 0.15, max = 30, layer = 7,
    r = function(s) return 0.15 end, off = function(s) return 0 end, rot = function(a) return rnd(0, 360) end,
    code = function(s) return "\\ornament" end },
}
local SMALLEST = 0.2       -- stop when the largest free disc is below this
local OVERLAP  = 0.95      -- existing discs count at this fraction of their radius
local REACH    = 1.9       -- a motif must be within this distance of an anchor
local GRID     = 0.2       -- candidate spacing (cm)

-- ---------------------------------------------------------------- region
-- rects = { {x0,y0,x1,y1}, ... }  (a union; shared edges are treated as open)
local function inside(r, x, y) return x > r[1] and x < r[3] and y > r[2] and y < r[4] end
local function border(rects, x, y)
  local best = -1
  for _, r in ipairs(rects) do
    if inside(r, x, y) then
      local d = math.huge
      local edges = { { x - r[1], r[1] - 0.05, y }, { r[3] - x, r[3] + 0.05, y }, { y - r[2], x, r[2] - 0.05 }, { r[4] - y, x, r[4] + 0.05 } }
      for _, e in ipairs(edges) do
        local open = false
        for _, o in ipairs(rects) do if o ~= r and inside(o, e[2], e[3]) then open = true end end
        if not open and e[1] < d then d = e[1] end
      end
      if d > best then best = d end
    end
  end
  return best
end

-- ---------------------------------------------------------------- main
function M.page(g)
  math.randomseed(g.seed)
  local out = {}                       -- per-layer buffers
  for i = 0, 7 do out[i] = {} end
  local function emit(layer, s) local b = out[layer]; b[#b + 1] = s end

  -- regions: the margin column, plus the space under the text on the last page
  local col = { 0.3, 0.7, g.colright, g.ph - 0.7 }
  local rects = { col }
  local spill
  if g.spill == 1 and (g.spilly - 0.9) - (g.ybot + 1.3) > 2.5 then
    spill = { g.colright, g.ybot + 1.3, g.textright - 0.2, g.spilly - 0.9 }
    rects[#rects + 1] = spill
  end

  -- vine: control points zig-zag up the column; the companion stalk is phase-shifted
  local cx, amp = g.colright * 0.47, g.colright * 0.1
  local pts, pts2 = {}, {}
  local n = 10
  for i = 0, n do
    local y = col[2] + 0.2 + (col[4] - col[2] - 0.4) * i / n
    pts[#pts + 1]   = { cx + amp * (i % 2 == 0 and -1 or 1) + rnd(-0.3, 0.3), y }
    pts2[#pts2 + 1] = { cx + amp * (i % 2 == 0 and 1 or -1) * 0.9 + rnd(-0.3, 0.3), y - 0.3 }
  end
  local vine = catmull(pts, 8)
  emit(0, "\\draw[florilegium stalk] plot[smooth,tension=0.6] coordinates {" .. coords(catmull(pts2, 8)) .. "};")
  emit(0, "\\draw[florilegium vine] plot[smooth,tension=0.6] coordinates {" .. coords(vine) .. "};")

  local anchors = {}
  for i = 1, #vine, 2 do anchors[#anchors + 1] = { vine[i][1], vine[i][2] } end

  -- a branch from the vine into the spill region, waving across it
  if spill then
    local sh = spill[4] - spill[2]
    local nb = math.max(1, math.floor(sh / 7))
    for b = 1, nb do
      local ymid = spill[2] + sh * (b - 0.5) / nb
      local best, bi = math.huge, 1
      for i, p in ipairs(vine) do local d = math.abs(p[2] - ymid) if d < best then best, bi = d, i end end
      local s0 = vine[bi]
      local ex, ey = spill[3] - 0.6, ymid + rnd(-0.2, 0.2) * sh / nb
      local h = math.min(0.8, sh / nb * 0.3)
      local sign = math.random() < 0.5 and 1 or -1
      local bp = {}
      for k = 0, 4 do
        local t = k / 4
        bp[#bp + 1] = { s0[1] + (ex - s0[1]) * t, s0[2] + (ey - s0[2]) * t + h * sin(2 * pi * t) * sign }
      end
      local br = catmull(bp, 8)
      emit(0, "\\draw[florilegium branch] plot[smooth,tension=0.6] coordinates {" .. coords(br) .. "};")
      for i = 1, #br, 2 do anchors[#anchors + 1] = { br[i][1], br[i][2] } end
    end
  end

  -- candidate grid with free radius and distance to the nearest anchor
  local gx, gy, free, adist = {}, {}, {}, {}
  for _, r in ipairs(rects) do
    local x = r[1] + GRID / 2
    while x < r[3] do
      local y = r[2] + GRID / 2
      while y < r[4] do
        local b = border(rects, x, y)
        if b > 0 then
          local i = #gx + 1
          gx[i], gy[i], free[i] = x, y, b
          local a = math.huge
          for _, p in ipairs(anchors) do local d = dist(x, y, p[1], p[2]) if d < a then a = d end end
          adist[i] = a
        end
        y = y + GRID
      end
      x = x + GRID
    end
  end
  local function add_disc(x, y, r)
    for i = 1, #gx do local d = dist(gx[i], gy[i], x, y) - OVERLAP * r if d < free[i] then free[i] = d end end
  end
  local function add_anchor(x, y)
    anchors[#anchors + 1] = { x, y }
    for i = 1, #gx do local d = dist(gx[i], gy[i], x, y) if d < adist[i] then adist[i] = d end end
  end
  local function nearest_anchor(x, y)
    local best, bp = math.huge, nil
    for _, p in ipairs(anchors) do local d = dist(x, y, p[1], p[2]) if d < best then best, bp = d, p end end
    return bp, best
  end
  local function stem(ax, ay, bx, by, w)
    local L = dist(ax, ay, bx, by)
    if L < 0.12 then return end
    local nx, ny = -(by - ay) / L, (bx - ax) / L
    local j1, j2 = rnd(-0.25, 0.25) * L, rnd(-0.25, 0.25) * L
    emit(1, fmt("\\draw[ink!85!black,line width=%spt] (%s,%s) .. controls (%s,%s) and (%s,%s) .. (%s,%s);",
      num(w), num(ax), num(ay),
      num(ax + 0.35 * (bx - ax) + nx * j1), num(ay + 0.35 * (by - ay) + ny * j1),
      num(ax + 0.7 * (bx - ax) + nx * j2), num(ay + 0.7 * (by - ay) + ny * j2),
      num(bx), num(by)))
  end

  -- the monogram plaque sits low on the left, before anything grows
  do
    local mx, my = col[1] + 0.75, col[2] + (col[4] - col[2]) * rnd(0.42, 0.58)
    emit(7, fmt("\\begin{scope}[shift={(%s,%s)}]\\monogram\\end{scope}", num(mx), num(my)))
    emit(7, fmt("\\begin{scope}[shift={(%s,%s)}]\\pendant{0.9}\\end{scope}", num(mx), num(my - 0.9)))
    add_disc(mx, my - 0.5, 1.0)
  end

  -- growth loop; the per-kind caps are for one margin column and scale with the area
  local area = 0
  for _, r in ipairs(rects) do area = area + (r[3] - r[1]) * (r[4] - r[2]) end
  local af = math.max(1, area / 165)
  local caps, counts = {}, {}
  for _, m in ipairs(motifs) do caps[m.name] = math.floor(m.max * af + 0.5); counts[m.name] = 0 end
  for iter = 1, 500 do
    local best, bi = -1, nil
    for i = 1, #gx do
      if adist[i] <= REACH then
        local v = free[i] * rnd(0.85, 1.15)
        if v > best then best, bi = v, i end
      end
    end
    if not bi or free[bi] < SMALLEST then break end
    local f, px, py = free[bi], gx[bi], gy[bi]

    -- choose a motif that fits the hole, weighted
    local elig, wsum = {}, 0
    for _, m in ipairs(motifs) do
      if counts[m.name] < caps[m.name] and m.r(m.smin) <= f * 1.05 then
        local ok = true
        if m.hangs_len then                 -- a pendant needs room below it
          ok = false
          for _, r in ipairs(rects) do if inside(r, px, py - m.hangs_len - 0.5) then ok = true end end
        end
        if ok then elig[#elig + 1] = m; wsum = wsum + m.w end
      end
    end
    if #elig == 0 then free[bi] = 0 else
      local pick, acc = elig[#elig], math.random() * wsum
      for _, m in ipairs(elig) do acc = acc - m.w if acc <= 0 then pick = m break end end
      -- scale so the proxy disc just fits the hole
      local s = pick.smax
      if pick.name == "flower" then s = math.max(0.7, s * (1 - 0.14 * counts.flower)) end
      if pick.r(s) > f * 0.92 then
        local lo, hi = pick.smin, s
        for _ = 1, 20 do local mid = (lo + hi) / 2 if pick.r(mid) > f * 0.92 then hi = mid else lo = mid end end
        s = lo
      end
      local anchor = nearest_anchor(px, py)
      local dx, dy = px - anchor[1], py - anchor[2]
      local L = sqrt(dx * dx + dy * dy)
      if L < 1e-6 then dx, dy, L = 1, 0, 1 end
      dx, dy = dx / L, dy / L
      local ang = deg(atan(dy, dx))
      local ox, oy, rot = px - dx * pick.off(s), py - dy * pick.off(s), 0
      if pick.hang then ox, oy = px, py + 0.45 * s end
      if pick.rot then rot = pick.rot(ang) end
      if pick.spiral then
        rot = deg(atan(-dy, -dx)) - 80          -- outer end of the spiral faces the anchor
        local ex, ey = px - dx * 1.07 * s, py - dy * 1.07 * s
        if pick.stem then stem(anchor[1], anchor[2], ex, ey, pick.stem) end
      elseif pick.stem then
        stem(anchor[1], anchor[2], ox, oy, pick.stem)
      end
      if pick.hangs_len then ox, oy = px, py + 0.5 end
      emit(pick.layer, fmt("\\begin{scope}[shift={(%s,%s)},rotate=%s]%s\\end{scope}", num(ox), num(oy), num(rot), pick.code(s, ang)))
      counts[pick.name] = counts[pick.name] + 1
      add_disc(px, py, pick.r(s))
      if pick.r(s) > 0.4 then add_anchor(px, py) end
      if pick.off(s) > 0.3 then add_anchor(ox, oy) end
    end
  end

  -- assemble: clip to the union of the regions, then the layers in depth order
  local clip = {}
  for _, r in ipairs(rects) do clip[#clip + 1] = fmt("(%s,%s) rectangle (%s,%s)", num(r[1]), num(r[2]), num(r[3]), num(r[4])) end
  local lines = { "\\begin{scope}", "\\clip " .. table.concat(clip, " ") .. ";" }
  for i = 0, 7 do for _, s in ipairs(out[i]) do lines[#lines + 1] = s end end
  lines[#lines + 1] = "\\end{scope}"
  tex.print(lines)
  if texio then texio.write_nl("florilegium: grew " .. tostring(#gx) .. " cells, " ..
    tostring((function() local c = 0 for _, v in pairs(counts) do c = c + v end return c end)()) .. " motifs") end
end

return M
